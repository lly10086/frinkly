# xiaoyi_crack
彩云小译Chrome插件破解版</br>

支持Chrome，Edge等浏览器</br>

*小译火力全开！LingoCloud, FIRE!*

#### 功能

- [x] 免登录、免注册
- [x] 自动视频翻译
- [x] 无限阅读次数

#### 教程

第一步、</br>

```bash
# 下载代码到本地
git clone https://github.com/cleviry/xiaoyi_crack
```

第二步、</br>

设置->扩展程序->打开`开发者模式`->加载已解压的扩展程序</br>

![image-20210429134137022](image-20210429134137022.png)

演示视频

[xiaoyi_crack使用教程_哔哩哔哩_bilibili](https://www.bilibili.com/video/BV14u411z77X/)

[xiaoyi开启自动翻译](https://www.bilibili.com/video/BV1zR4y1F7pU?from=search&seid=16637276319221217704&spm_id_from=333.337.0.0)

#### 注意

使用前请确认
- 已删除其他版本或同类型插件
- 已退出账户登录
- 清空浏览器数据重试

